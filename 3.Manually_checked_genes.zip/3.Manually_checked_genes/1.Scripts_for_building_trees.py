import pandas as pd
from os import system

#preinstall the NCBI Datasets command-line tools in your environment




def downloading_ncbi_data (selected_row=0, ):
    '''Download the required files from NCBI.
     In this case i downloaded proteomes and annotations.
    '''
    assembly_accession= ncbi_ids.iloc[selected_row]['Assembly_Accession']
    name_organism= ncbi_ids.iloc[selected_row]['Organism_Scientific_Name']
    name_downloaded_file= 'ncbi_dataset.zip'
    files_to_download='gff3,protein,seq-report' # you can download fasta genomes and more

    system(f'datasets download genome accession {assembly_accession} --include {files_to_download}')
    system(f'unzip -o {name_downloaded_file}')
    system(f'mkdir proteomes/{name_organism}')
    system(f'cp -r ncbi_dataset/data/{assembly_accession}/* proteomes/{name_organism}')
    system('rm -r ncbi_dataset*')


########################################################################
#opening file with the ncbi ids and downloadind the proteomes and their annotations
#ncbi_ids= pd.read_table ('ncbi_genome_ids.tsv', header=0)
#ncbi_ids.replace(' ', '_', regex=True, inplace=True)

#counter=0
#for organism in range (len(ncbi_ids['Organism_Scientific_Name'])):
#    downloading_ncbi_data (selected_row=counter)
#    counter= counter + 1#

#downloading proteomes for sources other than NCBI
#system('curl -o proteomes/Heliconius_erato/protein.faa.gz https://lepbase.cog.sanger.ac.uk/archive/v4/sequence/Heliconius_erato_lativitta_v1_-_proteins.fa.gz')
#system(f'gunzip proteomes/Heliconius_erato/protein.faa.gz')
#system('curl -o proteomes/Heliconius_erato/genomic.gff https://lepbase.cog.sanger.ac.uk/archive/v4/gff/heliconius_erato_lativitta_v1_core_32_85_1.gff')

#system('curl -o proteomes/Drosophila_melanogaster/protein.faa.gz http://ftp.flybase.net/releases/current/dmel_r6.59/fasta/dmel-all-translation-r6.59.fasta.gz')
#system(f'gunzip proteomes/Drosophila_melanogaster/protein.faa.gz')
###only download if necessary because is 6GB size
#system('curl -o proteomes/Drosophila_melanogaster/genomic.gff.gz  http://ftp.flybase.net/releases/current/dmel_r6.59/gff/dmel-all-r6.59.gff.gz') 
#system(f'gunzip proteomes/Drosophila_melanogaster/genomic.gff.gz')





#creating a multi-fasta file to be able to create a protein blast database
'''
name_multifasta= 'all_proteomes.faa'
text_line= []
for organism in ncbi_ids['Organism_Scientific_Name']:
    temp_1= f'proteomes/{organism}/protein.faa'
    text_line.append(temp_1)
    #print(f'proteomes/{organism}/protein.faa')
text_line_string= ' '.join(text_line) 
system('mkdir blast_database')
system(f'cat {text_line_string} > {name_multifasta}')
system(f'mv {name_multifasta} blast_database/')
'''

# print(text_line_string)
#print(text_line)


import subprocess
from Bio import SeqIO
import re


#align_sequences(input_file='merged_hmx_insects_blast.faa', output_file='alignment_amerged_hmx_insects_blast.faal')


def blast_results_merged(gene_name):
    #mkdir_command= f'mkdir {gene_name}'
    #mv_command= f'mv {gene_name}_blast {gene_name}/'
    cat_merging_files_command= f'cat {gene_name}/{gene_name}_blast/*.txt > {gene_name}/{gene_name}_blast/{gene_name}_merged_blast_from_insects.faa'
    #subprocess.call(mkdir_command, shell=True)
    #subprocess.call(mv_command, shell=True)
    subprocess.call(cat_merging_files_command, shell=True)

def removing_redundant_sequences(input_file, output_file):
    mmseqs2_command= f'mmseqs easy-cluster {input_file} {output_file} tmp --min-seq-id 0.9'
    subprocess.call(mmseqs2_command, shell=True)


def removing_duplicated_sequences(input_file, output_file):
    remove_seqs_command= f'seqkit rmdup {input_file} -o {output_file}'
    subprocess.call(remove_seqs_command, shell=True)

# Function to align sequences with MAFFT
def align_sequences(input_file, output_file):
    mafft_command = f"mafft --auto {input_file} > {output_file}"
    subprocess.call(mafft_command, shell=True)

def shorting_seqs_names(input_file, output_file):
    with open(input_file, "r") as input_handle, open(output_file, "w") as output_handle:
        for record in SeqIO.parse(input_handle, "fasta"):
            # Extract only the sequence ID (the part before the first space)
            record.id = record.id.split()[0]
            # Remove the full description to avoid length issues
            record.description = ""
            # Write the modified record to the output file
            SeqIO.write(record, output_handle, "fasta")


def gblocks_trimming (input_alignment):
    gblocks_command=f'Gblocks {input_alignment} -t=p -b5=h'
    subprocess.call(gblocks_command, shell=True)

def trimal_trimming (input_alignment, output_alignment, perc_gaps=0.7):
    trimal_command=f'trimal -in {input_alignment} -out {output_alignment} -gt {perc_gaps}'
    subprocess.call(trimal_command, shell=True)


def hmmer_profile(output_profile, input_alignment):
    hmmer_build_command=f'hmmbuild {output_profile} {input_alignment}'
    subprocess.call(hmmer_build_command, shell=True)

def hmmer_search(output_table, input_profile, proteomes):
    hmmer_search_command=f'hmmsearch --tblout {output_table} -E 1e-5 {input_profile} {proteomes}'
    subprocess.call(hmmer_search_command, shell=True)


def modify_identifiers(input_file, output_file):
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            # Remove commas from the line
            line = line.replace(',', '')  # Remove all commas
            line = line.replace(':', '')
            line = line.replace('[', '')
            line = line.replace(']', '')
            if line.startswith('>FBpp'):  # Handle FBpp format
                # Extract the ID part and remove '>'
                id_part = line.split()[0][1:]  # This is "FBpp0082400"

                # Extract the 'name' field
                name_part = line.split("name=")[1].split(";")[0]  # NK7.1-PA

                # Extract the species and translate it to "D. melanogaster"
                species_part = "D. melanogaster"  # Based on species=Dmel

                # Construct the modified line
                modified_line = f"{id_part} {name_part} {species_part}\n"

                # Write the modified line to the output file
                outfile.write(modified_line)

            elif line.startswith('>gnl|WGS:'):  # Handle WGS format
                # Extract the ID part after the last "|" and remove '>'
                id_part = line.split('|')[-1].strip()  # This is "TC009309-PA"

                # Add the species "[T.castaneum]"
                species_part = "T.castaneum"

                # Construct the modified line without the ">"
                modified_line = f"{id_part} {species_part}\n"

                # Write the modified line to the output file
                outfile.write(modified_line)
            else:
                # Remove the '>' symbol from lines that start with '>'
                if line.startswith('>'):
                    modified_line = line[1:].strip() + "\n"
                    outfile.write(modified_line)
                else:
                    # Write the unmodified line to the output file
                    outfile.write(line)



def replace_identifiers_in_tree(original_file, reference_file, output_file):
    # Step 1: Read the reference file and create a mapping
    identifier_map = {}
    
    with open(reference_file, 'r') as ref_file:
        for line in ref_file:
            parts = line.split(' ', 1)  # Split on the first space
            if len(parts) == 2:
                short_id = parts[0].strip()
                full_id = parts[1].strip().replace('(', '').replace(')', '')  # Remove parentheses
                identifier_map[short_id] = full_id

    # Step 2: Read the original file line by line to preserve format
    with open(original_file, 'r') as orig_file:
        lines = orig_file.readlines()
    
    # Step 3: Replace identifiers while preserving format
    updated_lines = []
    for line in lines:
        for short_id, full_id in identifier_map.items():
            # Avoid replacing identifiers that cause invalid formats
            line = re.sub(rf'\b{re.escape(short_id)}\b', f"{short_id} {full_id}", line)
        updated_lines.append(line)

    # Step 4: Write the modified content to the output file
    with open(output_file, 'w') as out_file:
        out_file.writelines(updated_lines)




def building_finalized_tree(gene_name):
    ###merging blast reults obtained manually
    blast_results_merged(gene_name=gene_name)

    input_file= f'{gene_name}/{gene_name}_blast/{gene_name}_merged_blast_from_insects.faa'
    output_file=f'{gene_name}/{gene_name}_alignment.fasta'

    ###clustering and removing redundant or too similar sequences
    mmseqs_output_folder=f'mkdir {gene_name}/{gene_name}_mmseqs_output'
    subprocess.call(mmseqs_output_folder, shell=True)
    output_file_remove_redundants=f'{gene_name}/{gene_name}_mmseqs_output/{gene_name}_merged_blast_from_insects'
    removing_redundant_sequences(input_file, output_file_remove_redundants)

    ###removing duplicated sequences
    input_file_representative_seqs=output_file_remove_redundants+'_rep_seq.fasta'
    output_file_representative_seqs=output_file_remove_redundants+'_rep_seq_unique.fasta'
    removing_duplicated_sequences(input_file=input_file_representative_seqs, output_file=output_file_representative_seqs)

    ###shortening the names of the sequences
    output_alignment_name_short_names=output_file_remove_redundants+'_rep_seq_unique_short_names.fasta'
    shorting_seqs_names(input_file=output_file_representative_seqs, output_file=output_alignment_name_short_names)

    ### sequence aligment
    mafft_output_folder=f'mkdir {gene_name}/{gene_name}_mafft_output'
    subprocess.call(mafft_output_folder, shell=True)
    output_file_alignment= f'{gene_name}/{gene_name}_mafft_output/{gene_name}_alignment.fasta'
    align_sequences(input_file=output_alignment_name_short_names, output_file=output_file_alignment)

    ### trimming alignment with trimal
    output_file_alignment_trimmed= f'{gene_name}/{gene_name}_mafft_output/{gene_name}_alignment_trimmed.fasta'
    trimal_trimming (input_alignment=output_file_alignment, output_alignment=output_file_alignment_trimmed, perc_gaps=0.5)

    ### buildinga hmmer profile
    hmmer_output_folder=f'mkdir {gene_name}/{gene_name}_hmmer_profile'
    subprocess.call(hmmer_output_folder, shell=True)
    output_hmmer_profile= f'{gene_name}/{gene_name}_hmmer_profile/{gene_name}.hmm'
    hmmer_profile(output_hmmer_profile, output_file_alignment_trimmed)

    ### Searching the proteomes for orthologs using the previously generated profile
    hmmer_search_output_folder=f'mkdir {gene_name}/{gene_name}_hmmer_search_output'
    subprocess.call(hmmer_search_output_folder, shell=True)
    output_table_profile= f'{gene_name}/{gene_name}_hmmer_search_output/{gene_name}_output_table.txt'
    proteomes_database= 'proteomes_database/all_proteomes.faa'
    hmmer_search(output_table_profile, input_profile= output_hmmer_profile, proteomes=proteomes_database)

    ###Taking the best 500 results
    hmmer_search_output_500hits=f'mkdir {gene_name}/{gene_name}_tree'
    subprocess.call(hmmer_search_output_500hits, shell=True)
    output_table_profile_500hits= f'{gene_name}/{gene_name}_tree/1_{gene_name}_output_table_500_hits.txt'
    hmmer_search_500hits_command=f"grep -v '^#' {output_table_profile} | head -n 500 > {output_table_profile_500hits}"
    subprocess.call(hmmer_search_500hits_command, shell=True)

    ###extracting the gene IDs from the hmmersearch results of the best 500 hits
    output__500hits_ids= f'{gene_name}/{gene_name}_tree/2_{gene_name}_output_500_hits_ids.txt'
    hmmer_search_500hits_ids_command=f"grep -v '^#' {output_table_profile_500hits} | awk '{{print $1}}' > {output__500hits_ids}"
    subprocess.call(hmmer_search_500hits_ids_command, shell=True)

    ###extracting the sequences from the hmmersearch results of the best 500 hits
    output__500hits_seqs= f'{gene_name}/{gene_name}_tree/3_{gene_name}_output_500_hits_seqs.fasta'
    extracting_selected_seqs_command=f'seqtk subseq {proteomes_database} {output__500hits_ids} > {output__500hits_seqs}'
    subprocess.call(extracting_selected_seqs_command, shell=True)

    ###removing duplicated sequences of the best 500 hits
    output_no_duplicated_seqs_500hits=f'{gene_name}/{gene_name}_tree/4_{gene_name}_output_500_hits_seqs_unique.fasta'
    removing_duplicated_sequences(input_file=output__500hits_seqs, output_file=output_no_duplicated_seqs_500hits)

    ### sequence aligment of the best 500 hits
    output_file_alignment_500_hits= f'{gene_name}/{gene_name}_tree/5_{gene_name}_output_500_hits_alignment.fasta'
    align_sequences(input_file=output_no_duplicated_seqs_500hits, output_file=output_file_alignment_500_hits)

    ###shortening the names of the aligned sequences of the best 500 hits
    output_alignment_short_names_500hits=f'{gene_name}/{gene_name}_tree/6_{gene_name}_output_500_hits_alignment_short_names_tmp.fasta'
    shorting_seqs_names(input_file=output_file_alignment_500_hits, output_file=output_alignment_short_names_500hits)

    ### shortening the name ids of the tribolium genes of the best 500 hits
    output_alignment_short_names_500hits_ranaming_tribolium= f'{gene_name}/{gene_name}_tree/6_{gene_name}_output_500_hits_alignment_short_names.fasta'
    alignment_short_names_500hits_2_command=f"sed 's/gnl|WGS:AAJJ|//' {output_alignment_short_names_500hits} > {output_alignment_short_names_500hits_ranaming_tribolium}"
    subprocess.call(alignment_short_names_500hits_2_command, shell=True)

    ### trimming alignment with trimal of the best 500 hits
    output_file_alignment_trimmed_500hits= f'{gene_name}/{gene_name}_tree/7_{gene_name}_output_500_hits_alignment_short_names_trimmed.fasta'
    trimal_trimming (input_alignment=output_alignment_short_names_500hits_ranaming_tribolium, output_alignment=output_file_alignment_trimmed_500hits, perc_gaps=0.5)

    ### trimming alignment with trimal of the best 500 hits
    creating_tree_command= f'iqtree2 -s {output_file_alignment_trimmed_500hits} -m TEST -bb 1000 -nt AUTO'
    subprocess.call(creating_tree_command, shell=True)

    iqtree2_output_folder=f'mkdir {gene_name}/{gene_name}_tree/{gene_name}_iqtree2_output'
    subprocess.call(iqtree2_output_folder, shell=True)
    iqtree2_output_folder_moving_command=f'mv {gene_name}/{gene_name}_tree/*.fasta.* {gene_name}/{gene_name}_tree/{gene_name}_iqtree2_output/'
    subprocess.call(iqtree2_output_folder_moving_command, shell=True)

    ###extracting the gene IDs and the full names from the hmmersearch results of the best 500 hits only unique ids
    output_500hits_full_ids= f'{gene_name}/{gene_name}_tree/8_{gene_name}_output_500_hits_full_ids.txt'
    hmmer_search_500hits_full_ids_command=f"grep '^>' {output_no_duplicated_seqs_500hits} > {output_500hits_full_ids}"
    subprocess.call(hmmer_search_500hits_full_ids_command, shell=True)

    ### shorten the names of the genes from Drosophila and Tribolium
    output_500hits_full_ids_modified = f'{gene_name}/{gene_name}_tree/9_{gene_name}_output_500_hits_full_ids_modified.txt'  # Specify the output file path
    modify_identifiers(output_500hits_full_ids, output_500hits_full_ids_modified)


    ###replace short ids with full gene names in the tree
    original_file= f'{gene_name}/{gene_name}_tree/{gene_name}_iqtree2_output/7_{gene_name}_output_500_hits_alignment_short_names_trimmed.fasta.treefile'
    output_tree_updated = f'{gene_name}/{gene_name}_tree/10_{gene_name}_output_500_hits_alignment_short_names_trimmed_updated.treefile'    # Path to save the updated content
    replace_identifiers_in_tree(original_file=original_file, reference_file=output_500hits_full_ids_modified, output_file=output_tree_updated)
    print(original_file)



#building_finalized_tree()

genes_2=['CG32971','exd','eya','MESR3','mld','Parp1']
genes_3=['otp', 'Drgx', 'foxo', 'Dll', 'grn', 'dac', 'GATAe', 'Gsc', 'gem', 'salr', 'disco-r', 'fkh',
          'CHES-1-like', 'LKRSDH', 'gt', 'gl', 'ham', 'Mtp', 'hry', 'CG34376', 'NK7.1', 'Mabi', 'CG34224']

for gene in genes_3:
    building_finalized_tree(gene_name= gene)
